<div class="notice notice-warning ccb-notice-warning">
	<p>
		<?php _e( 'Please install Cost-Calculator-Builder from <a href="https://wordpress.org/plugins/cost-calculator-builder/">WordPress.org</a>', 'cost-calculator-builder-pro' ); //phpcs:ignore ?>
	</p>
	<a class="ccb_install_button" href="https://wordpress.org/plugins/cost-calculator-builder/" target="_blank">
		<?php esc_html_e( 'Install', 'cost-calculator-builder-pro' ); ?>
	</a>
</div>
